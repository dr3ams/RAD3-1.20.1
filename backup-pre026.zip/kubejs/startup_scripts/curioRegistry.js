// priority: 0

console.info('curio registry loaded')

/* 
	///EXAMPLE
	
StartupEvents.registry('item', event => {
    event.create('test')
        .attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .curioTick((slotContext, stack) => { })
                .onEquip((slotContext, oldStack, newStack) => { })
                .onUnequip((slotContext, oldStack, newStack) => { })
                .canEquip((slotContext, stack) => true)
                .canUnequip((slotContext, stack) => true)
                .modifySlotsTooltip((tooltips, stack) => tooltips)
                .addAttribute(
                    "minecraft:generic.max_health",
                    UUID,
                    20,
                    'addition'
                )
                .modifyAttribute(attributeModificationContext => {
                    let { slotContext, UUID, stack, modifiers } = attributeModificationContext
                    attributeModificationContext.modify(
                        "minecraft:generic.armor",
                        "identifier",
                        20,
                        'addition'
                    )
                })
                .canDrop((slotContext, source, lootingLevel, recentlyHit, stack) => true)
                .modifyAttributesTooltip((tooltips, stack) => tooltips)
                .modifyFortuneLevel((slotContext, lootContext, stack) => 0)
                .modifyLootingLevel((slotContext, source, target, baseLooting, stack) => 0)
                .makesPiglinsNeutral((slotContext, stack) => false)
                .canWalkOnPowderedSnow((slotContext, stack) => false)
                .isEnderMask((slotContext, enderMan, stack) => false)
        )
        .maxStackSize(1)
        .tag("curios:head")
})

ItemEvents.modification(event => {
    event.modify('apple', item => {
        item.attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .curioTick((slotContext, stack) => { })
                .onEquip((slotContext, oldStack, newStack) => { })
                .onUnequip((slotContext, oldStack, newStack) => { })
                .canEquip((slotContext, stack) => true)
                .canUnequip((slotContext, stack) => true)
                .modifySlotsTooltip((tooltips, stack) => tooltips)
                .addAttribute(
                    "minecraft:generic.max_health",
                    "identifier",
                    20,
                    'addition'
                )
                .modifyAttribute(attributeModificationContext => {
                    let { slotContext, UUID, stack, modifiers } = attributeModificationContext
                    attributeModificationContext.modify(
                        "minecraft:generic.armor",
                        UUID,
                        20,
                        'addition'
                    )
                })
                .canDrop((slotContext, source, lootingLevel, recentlyHit, stack) => true)
                .modifyAttributesTooltip((tooltips, stack) => tooltips)
                .modifyFortuneLevel((slotContext, lootContext, stack) => 0)
                .modifyLootingLevel((slotContext, source, target, baseLooting, stack) => 0)
                .makesPiglinsNeutral((slotContext, stack) => false)
                .canWalkOnPowderedSnow((slotContext, stack) => false)
                .isEnderMask((slotContext, enderMan, stack) => false)
        )
    })
}) */


ItemEvents.modification(event => {
    event.modify('cataclysm:ring_of_grudged', item => {
        item.attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "attributeslib:crit_damage",
                    "identifier",
                    0.1,
                    'addition'
                )
        )
    })
    event.modify('cataclysm:vitality_ankh', item => {
        item.attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "attributeslib:healing_received",
                    "identifier",
                    0.2,
                    'addition'
                )
        )
    })
})


StartupEvents.registry('item', event => {
    event.create('vanilla_focus')
	    .maxStackSize(1)
		.tag('curios:an_focus')
		.tag('rad3:artifacts')
		.displayName('Vanilla Focus').color('gold')
		.rarity('Uncommon')
        .texture('kubejs:item/crafterfp')
        .attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "minecraft:generic.max_health",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    10,
                    'addition'
                )
                .addAttribute(
                    "skilltree:regeneration",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.25,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:base_melee_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    6,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:range_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    5,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:block_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    5,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:sprinting_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    5,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:swimming_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    5,
                    'addition'
                )
                .addAttribute(
                    "shieldinghealth:attribute.shieldinghealth.shield_value",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
                .addAttribute(
                    "forge:block_reach",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    1,
                    'addition'
                )
                .addAttribute(
                    "attributeslib:mining_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    1,
                    'multiply_base'
                )
                .addAttribute(
                    "combatroll:count",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.max_mana",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.mana_regen",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
        )

    event.create('archer_focus')
	    .maxStackSize(1)
		.tag('curios:an_focus')
		.tag('rad3:artifacts')
		.displayName('Way of the Archer').color('gold')
		.rarity('Uncommon')
        .texture('kubejs:item/roguefp')
        .attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "attributeslib:arrow_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    4,
                    'multiply_base'
                )
                .addAttribute(
                    "attributeslib:draw_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.1,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.movement_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.2,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.movement_speed",
                    "7107de5e-7ce8-4030-940e-514c1f160890",
                    -2.2,
                    'multiply_base'
                )
                .addAttribute(
                    "enhancedai:push_resistance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.knockback_resistance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'addition'
                )
                .addAttribute(
                    "combatroll:recharge",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.25,
                    'multiply_total'
                )
                .addAttribute(
                    "attributeslib:crit_chance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.95,
                    'addition'
                )
                .addAttribute(
                    "attributeslib:crit_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.25,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:sprinting_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    1,
                    'addition'
                )
                .addAttribute(
                    "skilltree:evasion",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
                .addAttribute(
                    "skilltree:blocking",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
                .addAttribute(
                    "minecraft:generic.luck",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'multiply_base'
                )
                .addAttribute(
                    "attributeslib:dodge_chance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1,
                    'multiply_total'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.mana_regen",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'multiply_total'
                )
        )

    event.create('mage_focus')
	    .maxStackSize(1)
		.tag('curios:an_focus')
		.tag('rad3:artifacts')
		.displayName('Way of the Battlemage').color('gold')
		.rarity('Uncommon')
        .texture('kubejs:item/wizardfp')
        .attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.spell_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    10,
                    'addition'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.max_mana",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.5,
                    'multiply_total'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.mana_regen",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.5,
                    'multiply_base'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.warding",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.1,
                    'multiply_total'
                )
                .addAttribute(
                    "minecraft:generic.attack_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.99,
                    'multiply_total'
                )
                .addAttribute(
                    "minecraft:generic.attack_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.66,
                    'multiply_total'
                )
                .addAttribute(
                    "attributeslib:draw_speed",
                    "dcaf3c5c-d125-4708-b5e9-54f7a09908e7",
                    -0.1,
                    'multiply_base'
                )
                .addAttribute(
                    "celestial_core:arrow_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.3,
                    'multiply_base'
                )
        )

    event.create('tank_focus')
	    .maxStackSize(1)
		.tag('curios:an_focus')
		.tag('rad3:artifacts')
		.displayName('Tank Focus').color('gold')
		.rarity('Uncommon')
        .texture('kubejs:item/fighterfp')
        .attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "l2damagetracker:damage_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.4,
                    'multiply_base'
                )
                .addAttribute(
                    "minecraft:generic.armor",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    5,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.armor_toughness",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    5,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.max_health",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    10,
                    'addition'
                )
                .addAttribute(
                    "shieldinghealth:attribute.shieldinghealth.shield_value",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    10,
                    'addition'
                )
                .addAttribute(
                    "shieldinghealth:attribute.shieldinghealth.shield_delay",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.25,
                    'multiply_base'
                )
                .addAttribute(
                    "shieldinghealth:attribute.shieldinghealth.shield_regen",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.25,
                    'multiply_base'
                )
                .addAttribute(
                    "attributeslib:healing_received",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.25,
                    'addition'
                )
                .addAttribute(
                    "skilltree:blocking",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    3,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.attack_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'multiply_total'
                )
                .addAttribute(
                    "attributeslib:arrow_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'multiply_total'
                )
                .addAttribute(
                    "celestial_core:armor_penetration",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.25,
                    'addition'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.spell_damage",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -5,
                    'addition'
                )
                .addAttribute(
                    "minecraft:generic.movement_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.2,
                    'multiply_total'
                )
                .addAttribute(
                    "forge:swim_speed",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.2,
                    'multiply_total'
                )
                .addAttribute(
                    "minecraft:generic.knockback_resistance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.5,
                    'addition'
                )
                .addAttribute(
                    "enhancedai:push_resistance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    1,
                    'addition'
                )
                .addAttribute(
                    "forge:entity_gravity",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    0.25,
                    'multiply_total'
                )
                .addAttribute(
                    "combatroll:recharge",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.33,
                    'multiply_total'
                )
                .addAttribute(
                    "combatroll:distance",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -1.0,
                    'multiply_total'
                )
                .addAttribute(
                    "betterparagliders:base_melee_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -3,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:range_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -3,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:sprinting_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -2,
                    'addition'
                )
                .addAttribute(
                    "betterparagliders:block_stamina_reduction",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    3,
                    'addition'
                )
                .addAttribute(
                    "ars_nouveau:ars_nouveau.perk.max_mana",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    -0.5,
                    'multiply_total'
                )
        )

    event.create('roguelite_ring')
	    .maxStackSize(1)
		.tag('curios:ring')
		.tag('rad3:artifacts')
		.displayName('Ring of Rebirth')
		.rarity('Rare')
        .texture('kubejs:item/roguelite_ring')
        .attachCuriosCapability(
            CuriosJSCapabilityBuilder.create()
                .addAttribute(
                    "minecraft:generic.max_health",
                    "1bc873d2-5603-4f79-9c7e-0bf796abbf99",
                    4,
                    'addition'
                )
        )
	
///END
})

StartupEvents.postInit(event => { Platform.mods.kubejs.name = 'RAD 3'; });
